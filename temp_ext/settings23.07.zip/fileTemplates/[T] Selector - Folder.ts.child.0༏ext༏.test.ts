import { StateSchema } from 'app/providers/StoreProvider';
import { ${NAME} } from './${NAME}';

describe('${NAME}.test', () => {
    test('should return correct value from state', () => {
        const state: DeepPartial<StateSchema> = {
            
        };
        expect(${NAME}(state as StateSchema)).toEqual(true);
    });
    test('should work with empty state', () => {
        const state: DeepPartial<StateSchema> = {};
        expect(${NAME}(state as StateSchema)).toEqual(false);
    });
});
