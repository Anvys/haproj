/**
* Created by ${USER} on ${DATE}
*/
import { IStateSchema } from 'app/providers/StoreProvider';

export const ${NAME} = (state: IStateSchema) => state.

