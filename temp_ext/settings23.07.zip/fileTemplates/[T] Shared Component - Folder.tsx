/**
* Created by ${USER} on ${DATE}
*/
import { FC } from 'react';
import { cn } from 'shared/lib/classNames/classNames';
import cls from './${NAME}.module.scss';

interface I${NAME}Props {
    className?: string
    // children?: ReactNode
}

export const ${NAME}: FC<I${NAME}Props> = (props) => {
    const { className } = props;
    return (
        <div className={cn(cls.${NAME}, {}, [className])}>
            
        </div>
    );
};